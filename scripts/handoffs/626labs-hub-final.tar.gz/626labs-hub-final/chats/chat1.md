# Session summary — 626labs.dev hub build

_Coding agent: Claude Code (Opus 4.7)_
_User: Este (626 Labs founder, Fort Worth TX)_
_Started from: minimal single-paragraph placeholder hub_
_Ended with: full portfolio shell at 626labs.dev_

---

## Arc

1. **Starting state.** `index.html` was a short landing page with five product cards (two flagship plugins, Sanduhr, two coming-soon), muted tokens, and a one-paragraph About. Live at 626labs.dev via GitHub Pages.

2. **Positioning pivot.** Este reframed the studio's thesis mid-session: "vibe coding plugins are the hot ticket — if we legitimize the category we look serious." That collapsed several decisions — plugins became the lede, Sanduhr moved to a supporting card, a "Thinking behind it" section introducing the Self-Evolving Plugin Framework became mandatory, and the Lab Dashboard became a flex proving "we pioneer this seriously."

3. **New sections.** Added in order:
   - *Thinking behind it* — framework thesis with a blockquote ("a plugin should be more useful on its tenth run than on its first") + supporting paragraphs, linking to the Apache-licensed spec doc.
   - *How the lab runs* — two screenshots of the private Lab Dashboard (Universe constellation + Operations project list), caption about the agent OS.
   - *Also from the lab* — JS-shuffled shelf of 8 portfolio pieces (Celestia 3, Project L.A.D.D.E.R., Lobby Engagement Suite, Safety Assistant, Cleanup Ranger, Tag That Line, Writer's Studio, Replit Certification). Video thumbnails for the three with YouTube demos; image thumbnails for the rest.
   - *Keep the lab running* — GitHub Sponsors CTA block.

4. **Sponsor wiring.** Added `.github/FUNDING.yml` pointing at Este's personal Sponsors account, mirrored into the four product repos. Nav + footer + support block all route to the same Sponsor URL. No Ko-fi / Buy Me a Coffee — "tip jar" framing undercuts the pioneer posture.

5. **Icon fix.** Discovered `favicon.png` was silently shipping as the Sanduhr hourglass. Wrote `scripts/crop-icon.py` — detects the text band in `logo.png` and auto-crops the hexagon+brain region. Regenerated to `favicon-626.png` + `assets/icon-626.png`.

6. **Design system drop.** Este dropped a full design system (`/Design/` — README, SKILL.md, `colors_and_type.css`, 15 preview cards, Lab Dashboard UI kit). Installed as the `626labs-design` Claude Code skill at `~/.claude/skills/626labs-design/`. Retuned the hub tokens to the brand palette (neon cyan `#17d4fa`, magenta `#f22f89`, navy `#0f1f31–#192e44`), Space Grotesk + Inter + JetBrains Mono. Every rgba() literal and shields.io URL swapped.

7. **Voice pass.** Este's voice-agent produced final copy for hero / about / thinking / how-the-lab-runs / support. Wired in verbatim. Earlier my draft had been too prose-y (I'd turned Este's tenacity notes into Thanos references) — reverted, wrote a copy brief for his voice-agent, then he delivered the final lines.

8. **Download-badge quirk.** shields.io returns a red "package not found or too new" SVG for freshly published npm packages. Added `maskStaleBadges()` — fetches each download badge post-load, inspects the SVG title, removes the img if it contains "not found" or "too new". Fresh packages render silently until npm stats catch up.

9. **Ops bones.** Added `.github/workflows/link-check.yml` — lychee-based broken-link checker that runs on push + weekly Mondays, excludes shields.io / YouTube rate-limit noise, opens issues only on scheduled failures. Paired with `scripts/notes/UPDATE-CHECKLIST.md` for the human-in-the-loop procedures.

10. **Design skin.** Este designed a portfolio shell in claude.ai/design; I implemented it — full rebuild with sticky glass nav, hero animated-ring logo stage, 6-col product grid with flagship variant, manifesto with 3 numbered principles, contact section, footer. Adapted the design's placeholder products (Agent OS as flagship, 5 plugin placeholders) to the real portfolio (Vibe Cartographer flagship + Vibe Doc + Vibe Test + Sanduhr + Vibe Sec WIP).

## Final product lineup (hub products section)

| Product | Status | Repo |
|---|---|---|
| **Vibe Cartographer** (flagship) | Live · v1.5.0 · Level 3.5 | github.com/estevanhernandez-stack-ed/vibe-cartographer |
| **Vibe Doc** | Live · v0.5.0 | github.com/estevanhernandez-stack-ed/Vibe-Doc |
| **Vibe Test** | Live · v0.2.3 (monorepo) | github.com/estevanhernandez-stack-ed/vibe-plugins/tree/main/packages/vibe-test |
| **Sanduhr für Claude** | Live · native | github.com/estevanhernandez-stack-ed/Sanduhr_f-r_Claude |
| **Vibe Sec** | Coming soon | github.com/estevanhernandez-stack-ed/vibe-plugins/tree/main/packages/vibe-sec |

## Also from the lab (8-entry shuffled pool)

- Celestia 3 — AI tarot/astrology, Swiss Ephemeris repaired to NASA-grade
- Project L.A.D.D.E.R. — local-first education, Gemma-powered
- Lobby Engagement Suite — 7 cinema + hotel kiosks on a shared monorepo
- Safety Assistant — live PDF hazard extraction, deployed on Replit
- Cleanup Ranger — civic park-cleanup app
- Tag That Line — word-tagging game
- Writer's Studio — VS Code template (Doctor Who special on Wattpad)
- Replit Certification — Level 3 Proficient Builder

## Key decisions logged to the 626 Labs Dashboard

- Product repos stay under personal namespace (`estevanhernandez-stack-ed`); `626Labs-LLC` org holds fork-mirrors only — keeps day-job code separated.
- 626labs.dev shipped on GitHub Pages under the new `626Labs-LLC` org.
- FUNDING.yml across all four product repos; no Ko-fi / Buy Me a Coffee.
- Vibe Test promoted from coming-soon to shipped after 0.2.0 released (third live plugin, first from the vibe-plugins monorepo).
- Full design system installed as `626labs-design` Claude Code skill.

## Deferred / next up

- **The admin panel** — this is the new ask this bundle is meant to inform.
- A public `/design` subpage rendering the `Design/preview/*.html` spec cards as a trust-signal page.
- Emoji → Lucide icon migration on the product cards (brand rule says no emoji in UI; the 🗺️📖🧪🛡️⏳ cards still violate).
- Interactive mini Dashboard in "How the lab runs" section (currently static screenshots).

## Session artifacts preserved in the repo

- `Design/` — full design system, 2.7MB
- `scripts/notes/` — copy-brief.md (voice agent hand-off), UPDATE-CHECKLIST.md (operational procedures), VIBE-ECOSYSTEM-BRIEFING.md (original session brief), copy-diff.md (line-by-line copy justification)
- `scripts/crop-icon.py` — regenerates favicon + header icon from logo.png
- `scripts/build-thumbnails.py` — regenerates derived thumbnails (Writer's Studio logo, Replit cert frame, book cover crop)
- `.github/workflows/link-check.yml` — lychee link checker
- `.github/FUNDING.yml` — Sponsor button routing
