# DESIGN AGENTS: READ THIS FIRST

This is a **context bundle** from a coding agent (Claude Code) who just finished shipping the 626 Labs portfolio hub at **626labs.dev**. The user ("Este") is handing this back to a design tool (claude.ai/design) so the next design conversation can brand-match pixel-perfectly and stay in voice.

## What the user wants next

A **desktop admin panel / dashboard** — the public-facing successor to the private "Lab Dashboard" that currently runs 626 Labs internally. The ask is explicit:

> "I want it to design a desktop admin panel I can run things from, you will make all the fancy parts of the dashboard that will easily let AI control and access."

So the design needs to assume:

1. **AI-controllable surface first.** Every panel, button, list, and filter should be addressable — clear state model, predictable IDs, visible affordances. An agent drives it as often as a human does.
2. **Desktop-native feel.** Not a cramped 16:9 marketing layout — a real tool surface. Sidebar navigation, dense information, keyboard-first interactions welcome.
3. **On-brand.** Match the portfolio hub's tokens, type, voice. The bundle includes the full design system.

## What's here

```
626labs-hub-final/
├── README.md                    ← you are here
├── chats/
│   └── chat1.md                 ← session summary (what the hub became and why)
├── project/
│   ├── index.html               ← live 626labs.dev source (inline styles)
│   └── assets/
│       ├── colors_and_type.css  ← brand token source of truth
│       ├── 626Labs-logo.png     ← primary brand lockup
│       ├── icon-626.png         ← icon-only mark (hexagon + brain)
│       ├── dashboard-universe.png  ← screenshot of current private dashboard (reference)
│       └── dashboard-projects.png  ← same dashboard, operations view
└── docs/
    ├── voice-brief.md           ← brand voice guardrails (no emoji, second person, etc.)
    └── update-checklist.md      ← operational context — what the hub displays + why
```

## Read order

1. **This README** — intent.
2. **`chats/chat1.md`** — the session arc. What shipped, what was deferred, why.
3. **`project/index.html`** — the current hub. Inline styles are the de facto pattern library; look at hero, nav, product cards (flagship + regular), "how the lab runs" section, and the manifesto principles.
4. **`project/assets/colors_and_type.css`** — tokens. Copy these verbatim into the admin panel — don't invent new ones.
5. **`docs/voice-brief.md`** — voice / tone rules. Strict: sentence case, no emoji in UI, no hedging verbs.

## Brand essentials — do not forget

- **Dark-mode first.** Deep navy base (`#0f1f31` → `#192e44`). Brightness is earned through signal, not decoration.
- **Neon duotone.** Cyan `#17d4fa` and magenta `#f22f89`. **Always pair them.** The signature gradient is 135° cyan → magenta.
- **Type:** Space Grotesk (display), Inter (body), JetBrains Mono (code + eyebrows).
- **Glow, not drop-shadow.** Dark-surface elevation uses `--glow-cyan / --glow-magenta / --glow-duo` for signaling.
- **Lucide-style icons.** 1.75px stroke, round joins, 16/20/24/32px. No emoji anywhere in product UI.
- **Pills and hairlines over heavy boxes.** The logo's rounded-hex silhouette is the geometric language.
- **Tagline:** *Imagine Something Else.*

## What the admin panel needs (user-specified and inferred)

The user runs 626 Labs through a private Agent OS. It currently has (from the screenshots):

- **Operation Center:** Projects · Universe · Decisions · Initiatives · The Architect · Goals & OKRs · Analytics
- **Build & Ship:** Workflows · GitHub · IDE Control
- **Agent Ops:** Actions · Council Debate

The public admin panel the user wants next should probably mirror / rethink these surfaces — not a straight copy, but a redesign that makes them AI-legible.

Specific design needs you should think about:

- **State visibility.** Every selection, filter, view, and mode should render as an affordance an agent can query.
- **Command palette.** Keyboard-first. Assume every meaningful action has a named command.
- **Eventful panels.** Surface recent activity, logs, diffs — things an agent emits or responds to.
- **Consistent information density.** The Universe view (visible in `dashboard-universe.png`) is the existing node-graph metaphor — honor it or evolve it, but don't ignore it.

## Don't

- Don't introduce a second brand palette. Use the existing tokens.
- Don't bring in emoji. The brand has a strict "no emoji in UI" rule — use Lucide icons instead.
- Don't use bouncy springs, scroll-triggered fades, or slow page transitions. Brand motion is subtle and fast (120/220/380ms, sharp out-easings).
- Don't design for mobile-first. This is a desktop tool. Responsive is a courtesy, not a driver.
- Don't invent products. The live portfolio at 626labs.dev lists the real four shipped products (Vibe Cartographer, Vibe Doc, Vibe Test, Sanduhr für Claude) and one coming (Vibe Sec). The admin panel is for running the studio — not re-advertising those.

## Ready

The hub is shipped and stable at 626labs.dev. Everything in this bundle is current as of the session end.
